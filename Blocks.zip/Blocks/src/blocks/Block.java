/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blocks;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/**
 *
 * @author M
 */
public class Block {

public float x=0;
public float y=0;

public float a=0;

public float vx=0;
public float vy=0;

public int size=20;

public int dimx=10;
public int dimy=10;

public float px1=0;
public float py1=0;

public float px2=0;
public float py2=0;

public float px3=0;
public float py3=0;

public float px4=0;
public float py4=0;

public float alpha=0;
public float alphav=0;
        
public float pxr1=0;
public float pyr1=0;

public float pxr2=0;
public float pyr2=0;

public float pxr3=0;
public float pyr3=0;

public float pxr4=0;
public float pyr4=0;

public float cpx=0;
public float cpy=0;

public float dx=0;
public float dy=0;

public boolean shoot_block=false;
public float shoot_alpha=0;
public float shoot_speed=0;
public float t=0.05f;
public float gravity_counter=0;

public boolean isColliding=false;

public boolean stop_moving=false;
public boolean stop=false;

public boolean setRed=false;

public boolean freeze=false;

public int stop_counter=0;

public static int nr_pointer=-1;

public int nr=0;
Block()
{
    Random r=new Random();
    
    gravity_counter=0;
    
    int ll=r.nextInt(10)+1;
    if(ll==10)
    {
    dimy=dimy*2;
    dimx=dimx*2;
    }
    else{
    int lll=r.nextInt(4)+1;
    dimy=dimy*lll;
    }
    
    
    
    int llll=r.nextInt(300)+1;
    alpha=llll;
    
    int lllll=r.nextInt(6)+1;
    if(lllll<3) vx=-0.1f*lllll;
    if(lllll>=3) vx=0.1f*lllll;
    
    int llllll=r.nextInt(6)+1;
    if(llllll<3) vy=0.1f*lllll;
    if(llllll>=3) vy=0.1f*lllll;
    
    px1=dimx;
    py1=-dimy;
    
    px2=-dimx;
    py2=-dimy;
    
    px3=-dimx;
    py3=dimy;
    
    px4=dimx;
    py4=dimy;
    
    r=new Random();
    int l=r.nextInt(640);

    x=l;
    l=r.nextInt(480);
    y=l;
    
    nr=nr_pointer++;
    
     l=r.nextInt(3);
        if(l>1){vx=(r.nextInt(10))*0.01f;}
        
        l=r.nextInt(3);
        if(l>1){vx=-(r.nextInt(10))*0.01f;}
    
    
    if(nr==0){
        vx=(r.nextInt(10))*0.1f;
        //vy=0.1f*rb.nextInt(14);
        vy=(r.nextInt(10))*0.1f;

        l=r.nextInt(3);
        if(l>1){vx=vx*-1;}
        
        l=r.nextInt(3);
        if(l>1){vy=vy*-1;}
    }
    
}

Block(float x,float y,int dx,int dy,float alpha)
{
    freeze=true;
    gravity_counter=0;
    this.x=x;
    this.y=y;
    this.dimx=dx;
    this.dimy=dy;
    
    px1=dimx;
    py1=-dimy;
    
    px2=-dimx;
    py2=-dimy;
    
    px3=-dimx;
    py3=dimy;
    
    px4=dimx;
    py4=dimy;
    
    this.alpha=alpha;
    
    nr=nr_pointer++;
}

public void rotate_block()
{
    if(shoot_block) 
        
    alphav=vx;
    
    alpha=alpha+alphav;
    if(alpha>360) alpha=0;
    
    
    if(alpha==0) alpha=0.1f;
    if(alpha==90) alpha=90.1f;
    if(alpha==180) alpha=180.1f;
    if(alpha==270) alpha=270.1f;
    if(alpha==360) alpha=0.1f;
    
    if(alpha<0) alpha=360;
    
}


public void rotate_points()
{
    //x ′ = x cos  ( θ ) − y sin 
    //y ′ = y cos  ( θ ) + x sin 
    rotate_block();
    
    float angle=(float)(alpha*3.14/180);
    
    pxr1=px1*(float)Math.cos(angle)-py1*(float)Math.sin(angle);
    pyr1=py1*(float)Math.cos(angle)+px1*(float)Math.sin(angle);
    pxr2=px2*(float)Math.cos(angle)-py2*(float)Math.sin(angle);
    pyr2=py2*(float)Math.cos(angle)+px2*(float)Math.sin(angle);
    pxr3=px3*(float)Math.cos(angle)-py3*(float)Math.sin(angle);
    pyr3=py3*(float)Math.cos(angle)+px3*(float)Math.sin(angle);
    pxr4=px4*(float)Math.cos(angle)-py4*(float)Math.sin(angle);
    pyr4=py4*(float)Math.cos(angle)+px4*(float)Math.sin(angle);
    
    pxr1=pxr1+x;
    pyr1=pyr1+y;
   
    pxr2=pxr2+x;
    pyr2=pyr2+y;
   
    pxr3=pxr3+x;
    pyr3=pyr3+y;
    
    pxr4=pxr4+x;
    pyr4=pyr4+y;
}

public void update_rotate_points()
{
    //x ′ = x cos  ( θ ) − y sin 
    //y ′ = y cos  ( θ ) + x sin 
    //rotate_block();
    
    float angle=(float)(alpha*3.14/180);
    
    pxr1=px1*(float)Math.cos(angle)-py1*(float)Math.sin(angle);
    pyr1=py1*(float)Math.cos(angle)+px1*(float)Math.sin(angle);
    pxr2=px2*(float)Math.cos(angle)-py2*(float)Math.sin(angle);
    pyr2=py2*(float)Math.cos(angle)+px2*(float)Math.sin(angle);
    pxr3=px3*(float)Math.cos(angle)-py3*(float)Math.sin(angle);
    pyr3=py3*(float)Math.cos(angle)+px3*(float)Math.sin(angle);
    pxr4=px4*(float)Math.cos(angle)-py4*(float)Math.sin(angle);
    pyr4=py4*(float)Math.cos(angle)+px4*(float)Math.sin(angle);
    
    pxr1=pxr1+x;
    pyr1=pyr1+y;
   
    pxr2=pxr2+x;
    pyr2=pyr2+y;
   
    pxr3=pxr3+x;
    pyr3=pyr3+y;
    
    pxr4=pxr4+x;
    pyr4=pyr4+y;
}

public void move()
{
            if(Blocks.shoot_started==false) return;
            
            float z=0.05f;
            
            if(shoot_block==false){
                
                if(freeze==false){
                            
                            if(gravity_counter>1600)
                            {
                                //System.out.println("gravity off");
                                x=x+vx;
                                y=y+vy;
                            }
                            else
                            {
                                
                                if(y>470) gravity_counter=1600;
                                gravity_counter++;
                                
                                //x=x+vx;
                                //y=y+vy;


                                float V=this.vx/10;
                                float r=(float)Math.sqrt(vx*vx+vy*vy);
                                V=r/10;
                                float co=vx/r;
                                float si=vy/r;

                                float A=(float)((180-this.shoot_alpha)*3.14159)/180;

                                float sX,sY;
                                //for(float t=z;t<30;t=t+z){

                                t=t+z;
                                sX=(float)(V*t*co);
                                sY=(float)-((V*t*si-((0.005*t*t)/2)));

                                if(Float.isNaN(sX)){sX=0.0f;}
                                //if(Float.isNaN(sY)){sY=-0.1f;}
                                alphav=2*sX;
                                x=x+sX;
                                
                                if(this.isColliding==false) y=y+sY;
                                //System.out.println(sX);
                                //System.out.println(sY);
                            }   
                }
            }
            
            
            
            if(shoot_block==true)
            {
            float V=this.shoot_speed/2;
            float A=(float)((180-this.shoot_alpha)*3.14159)/180;
            
            float sX,sY;
            //for(float t=z;t<30;t=t+z){
            //Block start_block=new Block(50+115,230+60,10,10,90);
                t=t+z;
                sX=(float)(V*t*Math.cos(A))+155;
                sY=(float)-((V*t*Math.sin(A)-((2.01*t*t)/2)))+290;
                x=sX;
                y=sY;
                
                dx=sX;
                dy=sY;
                
                
            //}
                    
            }
}

//draw lines for debug mode
public boolean check_Point2(Graphics gfx,float px,float py)
{
    update_rotate_points();
    boolean collision=false;
    
    //segment 1
    
    /*
    float a1=(pyr1+pyr2)/(-pxr1-pxr2);
    float b1=-a*pxr1-pyr1;
    float y1=-a1*px+b1;
    y1=-a1*0+b1;
    */
    /*
    y1=ax1+b
    y2=ax2+b
            y1+y2=a(x1+x2)+b;
            y1-y2=ax1-ax2
                   y1-y2 =a(x1-x2)
                           (y1-y2)/(x1-x2)=a
                                   y=ax+b
                                   y-ax=b
                                                   y1-ax=b
                                                   (y1-y2)/(x1-x2)=a
                                                   
                                                   b=y1-[(y1-y2)/(x1-x2)]x
    */
    gfx.setColor(Color.lightGray);
    gfx.drawLine((int)px,(int)py,(int)pxr1,(int)pyr1);
    
    gfx.setColor(Color.blue);
    gfx.drawLine((int)pxr1,(int)pyr1,(int)pxr2,(int)pyr2);
    
    float a=(pyr1-pyr2)/(pxr1-pxr2);
    float b=pyr1-a*pxr1;
    float sy1=a*px+b;
    
    float y1=a*0+b;
    float y11=a*600+b;            
    
    gfx.drawLine((int)0,(int)y1,(int)600,(int)y11);
    
    float a2=(pyr2-pyr3)/(pxr2-pxr3);
    float b2=pyr2-a2*pxr2;
    float sy2=a2*px+b2;
    
    float y2=a2*0+b2;
    float y22=a2*600+b2;            
    
    gfx.drawLine((int)0,(int)y2,(int)600,(int)y22);
    
    float a3=(pyr3-pyr4)/(pxr3-pxr4);
    float b3=pyr3-a3*pxr3;
    float sy3=a3*px+b3;
    
    float y3=a3*0+b3;
    float y33=a3*600+b3;
    
    gfx.drawLine((int)0,(int)y3,(int)600,(int)y33);
    
    float a4=(pyr4-pyr1)/(pxr4-pxr1);
    float b4=pyr4-a4*pxr4;
    float sy4=a4*px+b4;
    
    float y4=a4*0+b4;
    float y44=a4*600+b4;
    
    gfx.drawLine((int)0,(int)y4,(int)600,(int)y44);
    
    if(alpha>270&&alpha<360)
    {
        //if(py>=y1&&py<=y2&&py>=y4&&py<=y3) collision=true;
        if(py>=sy1&&py<=sy2)
        {
            if(py>=sy4&&py<=sy3)
            {
            collision=true;
            }
        }
        
    }
    
    if(alpha>0&&alpha<90)
    {
        //if(py>=y2&&py<=y3&&py>=y1&&py<=y4) collision=true;
        if(py>=sy2&&py<=sy3)
        {
            if(py>=sy1&&py<=sy4)
            {
            collision=true;
            }
        }
    }
    
    if(alpha>90&&alpha<180)
    {
        //if(py>=y3&&py<=y4&&py>=y2&&py<=y1) collision=true;
        if(py>=sy3&&py<=sy4)
        {
            if(py>=sy2&&py<=sy1)
            {
            collision=true;
            }
        
        }
    }
    
    if(alpha>180&&alpha<270)
    {
        //if(py>=y4&&py<=y1&&py>=y3&&py<=y2) collision=true;
        if(py>=sy4&&py<=sy1)
        {
            if(py>=sy3&&py<=sy2)
            {
            collision=true;
            }
        }
    }
    
    if(collision)
    {
    this.setRed=true;
    }
    
    return collision;
}

//check collision per vertices and rectangle segments
public boolean check_Point3(float px,float py)
{

    
     //float a=(py1-py2)/(px1-px2);
     //float b=py1-a*px1;
     //float y=a*px1+b;
    
    //System.out.println("a="+a);
    //System.out.println("b="+b);
    update_rotate_points();
    
    boolean collision=false;
    
    //segment 1
    
    /*
    float a1=(pyr1+pyr2)/(-pxr1-pxr2);
    float b1=-a*pxr1-pyr1;
    float y1=-a1*px+b1;
    y1=-a1*0+b1;
    */
    /*
    y1=ax1+b
    y2=ax2+b
            y1+y2=a(x1+x2)+b;
            y1-y2=ax1-ax2
                   y1-y2 =a(x1-x2)
                           (y1-y2)/(x1-x2)=a
                                   y=ax+b
                                   y-ax=b
                                                   y1-ax=b
                                                   (y1-y2)/(x1-x2)=a
                                                   
                                                   b=y1-[(y1-y2)/(x1-x2)]x
    */
    float a=(pyr1-pyr2)/(pxr1-pxr2);
    float b=pyr1-a*pxr1;
    float sy1=a*px+b;
    
    float y1=a*0+b;
    float y11=a*600+b;            
    
    float a2=(pyr2-pyr3)/(pxr2-pxr3);
    float b2=pyr2-a2*pxr2;
    float sy2=a2*px+b2;
    
    float y2=a2*0+b2;
    float y22=a2*600+b2;            
    
    float a3=(pyr3-pyr4)/(pxr3-pxr4);
    float b3=pyr3-a3*pxr3;
    float sy3=a3*px+b3;
    
    float y3=a3*0+b3;
    float y33=a3*600+b3;
    
    float a4=(pyr4-pyr1)/(pxr4-pxr1);
    float b4=pyr4-a4*pxr4;
    float sy4=a4*px+b4;
    
    float y4=a4*0+b4;
    float y44=a4*600+b4;
        
    if(alpha>270&&alpha<360)
    {
        //if(py>=y1&&py<=y2&&py>=y4&&py<=y3) collision=true;
        if(py>=sy1&&py<=sy2)
        {
            if(py>=sy4&&py<=sy3)
            {
            collision=true;
            }
        }
        
    }
    
    if(alpha>0&&alpha<90)
    {
        //if(py>=y2&&py<=y3&&py>=y1&&py<=y4) collision=true;
        if(py>=sy2&&py<=sy3)
        {
            if(py>=sy1&&py<=sy4)
            {
            collision=true;
            }
        }
    }
    
    if(alpha>90&&alpha<180)
    {
        //if(py>=y3&&py<=y4&&py>=y2&&py<=y1) collision=true;
        if(py>=sy3&&py<=sy4)
        {
            if(py>=sy2&&py<=sy1)
            {
            collision=true;
            }
        
        }
    }
    
    if(alpha>180&&alpha<270)
    {
        //if(py>=y4&&py<=y1&&py>=y3&&py<=y2) collision=true;
        if(py>=sy4&&py<=sy1)
        {
            if(py>=sy3&&py<=sy2)
            {
            collision=true;
            }
        }
    }
    
    if(alpha==0||alpha==180||alpha==360)
    {
        if(px<(x+dimx)&&px>(x-dimx))
        {
            if(py<(y+dimy)&&py>(y-dimy))
            {
                collision=true;
            }
        }
    }
    
    if(alpha==90||alpha==270)
    {
        if(px<(x+dimy)&&px>(x-dimy))
        {
            if(py<(y+dimx)&&py>(y-dimx))
            {
                collision=true;
            }
        }
    }
    
    if(collision)
    {
    //System.out.println(collision);
    this.setRed=true;
    }
    
    return collision;
    //System.out.println("a="+a);
}

public boolean check_Point(float px,float py)
{

    
     //float a=(py1-py2)/(px1-px2);
     //float b=py1-a*px1;
     //float y=a*px1+b;
    
    //System.out.println("a="+a);
    //System.out.println("b="+b);
    update_rotate_points();
    
    boolean collision=false;
    
    //segment 1
    float a1=(pyr1-pyr2)/(pxr1-pxr2);
    float b1=pyr1-a*pxr1;
    float y1=a1*px+b1;
    
    //segment 2
    float a2=(pyr2-pyr3)/(pxr2-pxr3);
    float b2=pyr2-a*pxr2;
    float y2=a2*px+b2;
    
    //segment 3
    float a3=(pyr3-pyr4)/(pxr3-pxr4);
    float b3=pyr3-a*pxr3;
    float y3=a3*px+b3;
    
    //segment 4
    float a4=(pyr4-pyr1)/(pxr4-pxr1);
    float b4=pyr4-a*pxr4;
    float y4=a4*px+b4;
    
    /*
    System.out.println("y1="+y1);
    System.out.println("y2="+y2);
    System.out.println("y3="+y3);
    System.out.println("y4="+y4);
    */
    
    
    if(alpha>270&&alpha<360)
    {
        //if(py>=y1&&py<=y2&&py>=y4&&py<=y3) collision=true;
        if(py>=y1&&py<=y2)
        {
            if(py>=y4&&py<=y3)
            {
            collision=true;
            }
        }
        
    }
    
    if(alpha>0&&alpha<90)
    {
        //if(py>=y2&&py<=y3&&py>=y1&&py<=y4) collision=true;
        if(py>=y2&&py<=y3)
        {
            if(py>=y1&&py<=y4)
            {
            collision=true;
            }
        }
    }
    
    if(alpha>90&&alpha<180)
    {
        //if(py>=y3&&py<=y4&&py>=y2&&py<=y1) collision=true;
        if(py>=y3&&py<=y4)
        {
            if(py>=y2&&py<=y1)
            {
            collision=true;
            }
        
        }
    }
    
    if(alpha>180&&alpha<270)
    {
        //if(py>=y4&&py<=y1&&py>=y3&&py<=y2) collision=true;
        if(py>=y4&&py<=y1)
        {
            if(py>=y3&&py<=y2)
            {
            collision=true;
            }
        }
    }
    
    
    if(collision)
    {
    //System.out.println(collision);
    this.setRed=true;
    }
    
    return collision;
    //System.out.println("a="+a);
}

public void check_Collision()
{
 if(x>=630){vx=vx*-1;}
 if(x<=10){vx=vx*-1;}
 
  //if(y>=470){vy=vy*-1;}
  if(y>=460){vy=-0.01f;}
  if(y<=10){vy=vy*-1;}
       
 //if(y>(480-size)){vy=0;vx=0;}
}

public void check_Collision_with_others(Block b)
{
 //if(b.x>=x-size&&b.x<=x+size)
 //{
 //   if(b.y>=y-size&&b.y<=y+size)
 //   {
    if(isColliding){
          if(stop==false||b.stop==false){
                    float vx1=vx;
                    float vy1=vy;

                    float vx2=b.vx;
                    float vy2=b.vy;

                    //if(vy2>=0&&vy2<=0.1){vy=0;b.vy=0;}
                    
                    float svx=(vx1+vx2)*0.05f;
                    float svy=(vy1+vy2)*0.05f;
                    

                    if(this.shoot_block)
                    {
                    svx=svx*20;
                    svy=svy*1;
                    }
                    //svy=(vy1+vy2)*0.5f+0.001f;;
                    float r=(float)(Math.sqrt(vx*vx+vy*vy));




                   if(svx<0.1) {svx=svx*2;}
                   if(svy<0.1) {svy=svy*2;}

                   if(svx>0.1&&svx<1) {svx=svx*1.2f;}
                   if(svy>0.1&&svy<1) {svy=svy*1.2f;}

                    b.vx=-2f*svx;
                    b.vy=-2f*svy;

                    vx=2f*svx*0.5f;
                    vy=2f*svy*0.5f;

                    if(b.vx<=0.1&&b.vy<=0.1)
                    {b.vx=0.1f;b.vy=0.1f;
                     Random r2=new Random();
                     vx=(r2.nextInt(3))*0.1f;
                     //vy=0.1f*rb.nextInt(14);
                     vy=(r2.nextInt(3))*0.1f;

                     int l2=r2.nextInt(3);
                     if(l2>1){vx=vx*-1;}

                     l2=r2.nextInt(3);
                     //if(l2>1){vy=vy*-1;}
                    }

                    /*
                    if(x>=630){vx=1.1f*vx*-1;}
                    if(x<=10){vx=1.1f*vx*-1;}

                    if(y>=460){vy=1.1f*vy*-1;}
                    if(y<=10){vy=1.1f*vy*-1;}
                    */

                    //if(svy>=0&&svy<=0.1){svy=0;vy=0;b.vy=0;}
                    //if(vy<=0)vy=-vy;
                    //if(b.vy<=0)b.vy=-b.vy;



                    
            }
            
                    if(y>450) {vy=vy/10;vx=vx/10;alphav=alphav/10;stop_moving=true;}
                    if(b.y>450) {b.vy=b.vy/10;b.vx=b.vx/10;b.alphav=b.alphav/10;b.stop_moving=true;}
                    
                    if(y<b.y)
                    {
                         b.vy=b.vy+0.01f;
                         vy=vy-0.01f;
                    }
                    if(y>b.y)
                    {
                         vy=vy+0.01f;
                    }  
          
       if(stop_moving==true){stop_counter++;}
       if(b.stop_moving==true){b.stop_counter++;stop_moving=true;}
       
       if(stop_counter==30){vx=0;vy=0;stop=true;}
       //alphav=0;
       //if(b.stop_counter==1000){b.vx=0;b.vy=0;b.alphav=0;}
    }
 
 //}
 
                    //if(y>450) {vy=vy/10;vx=vx/100;alphav=alphav/100;stop_moving=true;}
                    //if(b.y>450) {b.vy=b.vy/100;b.vx=b.vx/100;b.alphav=b.alphav/100;b.stop_moving=true;}
                    
                    if(y<b.y)
                    {
                         b.vy=b.vy+0.00001f;
                    }
                    if(y>b.y)
                    {
                         vy=vy+0.00001f;
                    }
                    
}




}
