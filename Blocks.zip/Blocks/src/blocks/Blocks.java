package blocks;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * Mateusz Pawlowski
 */
public class Blocks extends JPanel implements Runnable,MouseListener,MouseMotionListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Blocks");
    public Thread thread;
    
    static public int level=0;
    
    JButton lev=new JButton("Lv "+level);
    JButton b1=new JButton("Shoot");
    JButton b2=new JButton("Bricks");
    JButton b3=new JButton("Collision");
                
    public Graphics gfx;
    
    public int counter=0;
    
    
    
    public Block sblock;
    
    public static boolean simulation=false;
    
    public static boolean draw_debug_mode=false;
    public static boolean unfreezing=true;
    
    public static boolean shoot_started=false;
    public float shoot_r=0;
    
    int old_mouse_x=0;
    int old_mouse_y=0;
    boolean mouse_pressed=false;
    float shoot_power=0;
    
    public ArrayList<Block> list=new ArrayList<Block>();
    
    /**
     * @param args the command line arguments
     */
    public Blocks()
    {
        counter=0;
        this.add(lev);
        this.add(b1);
        this.add(b2);
        this.add(b3);
        
        this.addMouseMotionListener(this);
        this.addMouseListener(this);
        
        lev.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae)
                {
                    level++;
                    if(level==4) level=0;
                    lev.setText("Lv "+level);
                }
            }
        );
        
        b1.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae)
                {
                    simulation=false;shoot_started=false;
                    
                    reload();
                }
            }
        );
        
        b2.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae){simulation=true;shoot_started=true;reload();}
            }
        );
        b3.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae){if(draw_debug_mode==false){draw_debug_mode=true;}else{draw_debug_mode=false;}}
            }
        );
        
        list=new ArrayList<Block>();
       
        if(simulation){
            for(int q=0;q<8;q++)
            {
                Block b=new Block();
                list.add(b);
            }
        }
        
        if(simulation==false){
        
            
        if(level==0){
        list.add(new Block(335,200,10,30,0));
        list.add(new Block(250+152,100+100,10,30,359));
        list.add(new Block(250+115,100+60,10,30,90));
        
        
        list.add(new Block(250+100-15,100+183,10,29,3));
        list.add(new Block(250+150,100+183,10,29,355));
        list.add(new Block(250+115,100+143,10,28,90));
        
        list.add(new Block(250+100-15,100+183+83,10,30,0));
        list.add(new Block(250+150,100+183+83,10,30,359));
        list.add(new Block(250+115,100+143+83,10,30,90));
        }
        
        if(level==1){
        list.add(new Block(250+100-16,100+100,10,30,5));
        list.add(new Block(250+152+52,100+100,10,30,359));
        Block b=new Block(250+115,100+60-15,10,30,45);
        list.add(new Block(250+115+60,100+60-15,10,30,45+90));
        //b.vy=-1;
        list.add(b);
        
        list.add(new Block(250+100-15,100+183,10,29,3));
        list.add(new Block(250+150+52,100+183,10,29,355));
        Block b2=new Block(250+115-2,100+143,10,30,90);
        list.add(new Block(250+115+60+2,100+143,10,30,90));
        //b2.vy=-1;
        list.add(b2);
        
        list.add(new Block(250+100-15,100+183+85,10,30,0));
        list.add(new Block(250+150+52,100+183+85,10,30,359));
        Block b3=new Block(250+115-2,100+143+83,10,30,90);
        list.add(new Block(250+115+60+2,100+143+83,10,30,90));
        //b3.vy=-1;
        list.add(b3);
        }
        
        if(level==2){
        
        
        list.add(new Block(250+115-5,100+60-15-30+10,10,30,90));
        Block b=new Block(250+115-70,100+60-15,10,30,60);
        list.add(new Block(250+115+60,100+60-15,10,30,180-60));
        //b.vy=-1;
        list.add(b);
        
        list.add(new Block(250+115-70-50,100+60-15+50,10,30,30));
        list.add(new Block(250+115+60+50,100+60-15+50,10,30,180-30));
        
        list.add(new Block(250+115-70-70,100+60-15+110,10,29,3));
        list.add(new Block(250+115+60+70,100+60-15+110,10,29,355));
        }
        
        Block start_block=new Block(50+115,230+60,10,10,90);
        sblock=start_block;
        
        start_block.freeze=false;
        
        start_block.shoot_block=true;
        start_block.shoot_alpha=-10;
        start_block.shoot_speed=-100f;
        
        start_block.vx=1;
        start_block.vy=0f;
        list.add(start_block);
        }
        
        if(level==3){
        
        
        list.add(new Block(250+115+2,100+60-15+4,10,30,45));
        list.add(new Block(250+115+60+1,100+60-15+4,10,30,45+90));
        
        list.add(new Block(250+115-60,100+60-15+60,10,30,45));
        list.add(new Block(250+115+60-60,100+60-15+60,10,30,45+90));
        
        list.add(new Block(250+115+60,100+60-15+60,10,30,45));
        list.add(new Block(250+115+60+60,100+60-15+60,10,30,45+90));
        
        list.add(new Block(250+115-60-60-2,100+60-15+120-5,10,30,45));
        list.add(new Block(250+115+60-60-60-2,100+60-15+120-5,10,30,45+90));
        
        list.add(new Block(250+115+60-60-2,100+60-15+120-5,10,30,45));
        list.add(new Block(250+115+60+60-60-2,100+60-15+120-5,10,30,45+90));
        
        list.add(new Block(250+115+60-60+120-2,100+60-15+120-5,10,30,45));
        list.add(new Block(250+115+60+60-60+120-2,100+60-15+120-5,10,30,45+90));
        }
        
    }
    
    public void reload()
    {
                    this.frame.dispose();   
                    Blocks r=new Blocks();
                    Block.nr_pointer=-1;
                    
                    r.panel = r;
                    r.frame = new JFrame("Blocks");
                    r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    r.frame.getContentPane().add(r.panel);
                    r.panel.setSize(300, 300);
                    r.frame.setLocation(500, 300);
                    r.frame.pack();
                    r.frame.show();
                    r.thread=new Thread(r);
                    r.thread.start();
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
       
        Blocks r=new Blocks();
        r.reload();
        /*
        Blocks r=new Blocks();
        r.panel = r;
        r.frame = new JFrame("Blocks");
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        r.frame.getContentPane().add(r.panel);
        r.panel.setSize(300, 300);
        r.frame.setLocation(500, 300);
        r.frame.pack();
        r.frame.show();
        r.thread=new Thread(r);
        r.thread.start();
        */
        
    }

    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        
        g.setColor(Color.white);
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        if(simulation==false){
            
            g.setColor(new Color(0,255,0));
            
            
            
            
            float dx=(old_mouse_x-sblock.x);
            float dy=(sblock.y-old_mouse_y);
            
            float r=(float)Math.sqrt(dx*dx+dy*dy);
            this.shoot_r=-r/2f;
            
            float ang=(dy/r);
            float ang2=90-(float)Math.acos(ang)*(180/3.14f);
            ang=ang2;
            if(dx<0) ang=90;
            
            
            if(shoot_started==false){
            g.drawLine((int)sblock.x,(int)sblock.y, old_mouse_x, old_mouse_y);
            sblock.shoot_alpha=-ang;
            }
            
            //System.out.println("angle= "+ang2);
            
        }
        
        for(Block b:list)
        {
        //System.out.println(""+b.alpha);
        g.setColor(Color.black);
        g.drawLine((int)b.pxr1,(int)b.pyr1,(int)b.pxr2,(int)b.pyr2);
        g.drawLine((int)b.pxr2,(int)b.pyr2,(int)b.pxr3,(int)b.pyr3);
        g.drawLine((int)b.pxr3,(int)b.pyr3,(int)b.pxr4,(int)b.pyr4);
        g.drawLine((int)b.pxr4,(int)b.pyr4,(int)b.pxr1,(int)b.pyr1);
        
        
        boolean colors=false;
        if(colors==true)
        {
        g.setColor(Color.black);
        g.drawLine((int)b.pxr1,(int)b.pyr1,(int)b.pxr2,(int)b.pyr2);
        g.setColor(Color.blue);
        g.drawLine((int)b.pxr2,(int)b.pyr2,(int)b.pxr3,(int)b.pyr3);
        g.setColor(Color.green);
        g.drawLine((int)b.pxr3,(int)b.pyr3,(int)b.pxr4,(int)b.pyr4);
        g.setColor(Color.orange);
        g.drawLine((int)b.pxr4,(int)b.pyr4,(int)b.pxr1,(int)b.pyr1);
                
        g.setColor(Color.black);
        g.fillRect((int)(b.pxr1-2),(int)(b.pyr1-2), 4, 4);
        
        g.setColor(Color.blue);
        g.fillRect((int)(b.pxr2-2),(int)(b.pyr2-2), 4, 4);
        
        g.setColor(Color.green);
        g.fillRect((int)(b.pxr3-2),(int)(b.pyr3-2), 4, 4);
        
        g.setColor(Color.orange);
        g.fillRect((int)(b.pxr4-2),(int)(b.pyr4-2), 4, 4);
        }
       
        /*
        if(b.setRed)
        {
        g.setColor(Color.blue);
        g.drawLine((int)b.pxr1,(int)b.pyr1,(int)b.pxr2,(int)b.pyr2);
        g.drawLine((int)b.pxr2,(int)b.pyr2,(int)b.pxr3,(int)b.pyr3);
        g.drawLine((int)b.pxr3,(int)b.pyr3,(int)b.pxr4,(int)b.pyr4);
        g.drawLine((int)b.pxr4,(int)b.pyr4,(int)b.pxr1,(int)b.pyr1);
        }
        */     
        
        
        
        if(draw_debug_mode){
        int colc=0;
                            for(Block bb:list)
                                   {
                                   colc++;
                                   if(colc==1){
                                   g.setColor(new Color(0,colc*50,0));
                                   //g.fillRect((int)bb.pxr1,(int)bb.pyr1,8,8);
                                   }
                                   
                                   int colc2=0;
                                   for(Block bb2:list)
                                   {
                                       if(bb2.equals(bb)==false){

                                           bb2.update_rotate_points();
                                           colc2++;
                                           //b2.check_Collision_with_others(b);
                                           boolean collision=false;

                                            /*
                                            if(colc2!=1){
                                            g.setColor(Color.black);
                                            g.fillRect((int)bb2.pxr1,(int)bb2.pyr1,2,2);
                                            g.fillRect((int)bb2.pxr2,(int)bb2.pyr2,2,2);
                                            g.fillRect((int)bb2.pxr3,(int)bb2.pyr3,2,2);
                                            g.fillRect((int)bb2.pxr4,(int)bb2.pyr4,2,2);
                                            }
                                            */
                                           
                                           if(colc==1){
                                           if(bb.check_Point2(g,bb2.pxr1,bb2.pyr1)==true) collision=true;
                                           if(bb.check_Point2(g,bb2.pxr2,bb2.pyr2)==true) collision=true;
                                           if(bb.check_Point2(g,bb2.pxr3,bb2.pyr3)==true) collision=true;
                                           if(bb.check_Point2(g,bb2.pxr4,bb2.pyr4)==true) collision=true;
                                           }
                                       }
                                   }
                                   }
        }
        }
    }
    
    public void run() {
        while(true&&counter!=2000){
            try{
            //counter++;
            
            if(simulation==false&&mouse_pressed)
            {
                if(shoot_power<100) shoot_power=shoot_power+0.3f;
                 
                    //start_block.shoot_alpha=-10;
                    
                    //sblock.shoot_speed=-shoot_power;
            }
            if(simulation==false&&mouse_pressed==false)
            {
                if(shoot_power>0) shoot_power=shoot_power-0.3f;
            }
            
                for(Block b:list)
                {
                //b.calc_points();
               
                b.move();
                b.rotate_points();

                for(Block b2:list)
                {
                    if(b2.equals(b)==false){
                        
                        b.update_rotate_points();
                        
                        //b2.check_Collision_with_others(b);
                        boolean collision=false;
                        
                        //if(b2.is_Colliding(b.pxr1,b.pyr1)==true) collision=true;
                        //if(b2.is_Colliding(b.pxr2,b.pyr2)==true) collision=true;
                        //if(b2.is_Colliding(b.pxr3,b.pyr3)==true) collision=true;
                        //if(b2.is_Colliding(b.pxr4,b.pyr4)==true) collision=true;
                        //b.cpx=b2.pxr1;
                        //b.cpy=b2.pyr1;
                        
                        
                        
                         
                         
                        /* 
                        if(b.check_Point(b2.pxr1,b2.pyr1)==true) collision=true;
                        if(b.check_Point(b2.pxr2,b2.pyr2)==true) collision=true;
                        if(b.check_Point(b2.pxr3,b2.pyr3)==true) collision=true;
                        if(b.check_Point(b2.pxr4,b2.pyr4)==true) collision=true;
                        */
                        if(b.check_Point3(b2.pxr1,b2.pyr1)==true) collision=true;
                        if(b.check_Point3(b2.pxr2,b2.pyr2)==true) collision=true;
                        if(b.check_Point3(b2.pxr3,b2.pyr3)==true) collision=true;
                        if(b.check_Point3(b2.pxr4,b2.pyr4)==true) collision=true;
                        
                        if(collision==true)
                        {
                            b2.isColliding=true;b2.freeze=false;
                            if(unfreezing==false)
                            {
                            unfreezing=true;
                            for(Block bl:list)
                            {
                            bl.freeze=false;
                            //bl.vy=0.1f;
                            }
                            }
                        }
                        
                        if(collision==false){b2.isColliding=false;}
                        b2.check_Collision_with_others(b);
                    }
                }

                b.check_Collision();

                
                }

                this.repaint();
                Thread.sleep(4);
                                
            }catch(Exception exc){};
            
            
            if(counter==2000)
            {
                    this.frame.dispose();   
                    
                    Blocks r=new Blocks();
                    
                    Block.nr_pointer=-1;
                    
                    r.panel = r;
                    r.frame = new JFrame("Blocks");
                    r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    r.frame.getContentPane().add(r.panel);
                    r.panel.setSize(300, 300);
                    r.frame.setLocation(500, 300);
                    r.frame.pack();
                    r.frame.show();
                    r.thread=new Thread(r);
                    r.thread.start();
            }
        
        
       
        }
        
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
        
        if(e.getButton()==1)
         {
             mouse_pressed=true;
         }
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
        mouse_pressed=false;
        Blocks.shoot_started=true;
        sblock.shoot_speed=this.shoot_r;
                
        //System.out.println("mouse released");
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        if(e.getY()>old_mouse_y)
        {
                        
        }
        if(e.getY()<old_mouse_y)
        {
                        
        }
        this.old_mouse_x=e.getX();
        this.old_mouse_y=e.getY();  
    }
    
}
